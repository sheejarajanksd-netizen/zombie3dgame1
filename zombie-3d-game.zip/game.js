let scene, camera, renderer;
let player, zombies = [], bullets = [];
let zombieCount = 5;
let gameOver = false;

init();
animate();

function init() {
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
  camera.position.z = 5;

  renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.getElementById('gameContainer').appendChild(renderer.domElement);

  const light = new THREE.AmbientLight(0xffffff, 0.5);
  scene.add(light);

  const dirLight = new THREE.DirectionalLight(0xffffff, 1);
  dirLight.position.set(5, 10, 7.5);
  scene.add(dirLight);

  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(100, 100),
    new THREE.MeshLambertMaterial({ color: 0x222222 })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.5;
  scene.add(ground);

  const geometry = new THREE.BoxGeometry(1, 1, 1);
  const material = new THREE.MeshLambertMaterial({ color: 0x00ff00 });
  player = new THREE.Mesh(geometry, material);
  scene.add(player);

  spawnZombies(zombieCount);

  window.addEventListener('click', shoot);
  window.addEventListener('keydown', handleMovement);
}

function handleMovement(e) {
  if (e.key === 'ArrowLeft') player.position.x -= 0.5;
  if (e.key === 'ArrowRight') player.position.x += 0.5;
}

function spawnZombies(count) {
  for (let i = 0; i < count; i++) {
    const geo = new THREE.BoxGeometry(1, 1, 1);
    const mat = new THREE.MeshLambertMaterial({ color: 0xff0000 });
    const zombie = new THREE.Mesh(geo, mat);

    zombie.position.x = (Math.random() - 0.5) * 20;
    zombie.position.z = (Math.random() * -20) - 10;

    zombies.push(zombie);
    scene.add(zombie);
  }

  document.getElementById("zombieCount").innerText = zombies.length;
}

function shoot() {
  if (gameOver) return;

  document.getElementById('shootSound').play();

  const bullet = new THREE.Mesh(
    new THREE.SphereGeometry(0.1),
    new THREE.MeshBasicMaterial({ color: 0xffffff })
  );
  bullet.position.copy(player.position);
  bullets.push(bullet);
  scene.add(bullet);
}

function animate() {
  if (gameOver) return;

  requestAnimationFrame(animate);

  zombies.forEach((zombie, index) => {
    zombie.position.z += 0.03;
    zombie.rotation.y += 0.01;

    if (zombie.position.z > 4 && !gameOver) {
      gameOver = true;
      setTimeout(() => alert("Game Over!"), 100);
    }
  });

  bullets = bullets.filter(bullet => {
    bullet.position.z -= 0.2;

    for (let i = zombies.length - 1; i >= 0; i--) {
      if (bullet.position.distanceTo(zombies[i].position) < 0.8) {
        scene.remove(zombies[i]);
        zombies.splice(i, 1);
        scene.remove(bullet);
        document.getElementById("zombieCount").innerText = zombies.length;

        if (zombies.length === 0 && !gameOver) {
          gameOver = true;
          setTimeout(() => alert("You Win!"), 100);
        }
        return false;
      }
    }

    return bullet.position.z > -50;
  });

  renderer.render(scene, camera);
}
